<?php include 'header.php'; ?>
	<div class="container">
		<div class="panel-body">
	<h2>SELAMAT DATANG DI HALAMAN SPP</h2>
	<!-- <H5>DATA GURU SMK TI GARUDA NUSANTARA</H5> -->
 <a class="btn btn-info" href="./">Home</a>
            <a class="btn btn-info" href="dataguru.php">DATA GURU</a></li>

            <a class="btn btn-info" href="datawali.php">DATA KELAS</a>
            <a class="btn btn-info" href="dataadmin.php">DATA ADMIN</a>
            <a class="btn btn-info" href="datasiswa.php">DATA SISWA</a>
            <a  class="btn btn-info"href="transaksi.php">TRANSAKSI</a>
            <a class="btn btn-info"href="laporan.php">LAPORAN</a>
            <a class="btn btn-info"href="logout.php">LOGOUT</a>
</div>
</div>

	
 
<?php include 'footer.php'; ?>